var Life = artifacts.require("./Life.sol");

module.exports = function(deployer) {
  deployer.deploy(Life);
};
