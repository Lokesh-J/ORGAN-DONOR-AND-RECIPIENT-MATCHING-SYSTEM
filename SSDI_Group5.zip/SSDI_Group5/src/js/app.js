App = {
  web3Provider: null,
  contracts: {},
  account: '0x0',

  init: function() {
    return App.initWeb3();
  },

  initWeb3: async function() {
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      try {
        await window.ethereum.enable();
      } catch (error) {
        console.error("User denied account access")
      }
    }
    else if (typeof web3 !== 'undefined') {
      App.web3Provider = web3.currentProvider;
    } else {
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
    }
    web3 = new Web3(App.web3Provider);
    return App.initContract();
  },

  initContract: function() {
    $.getJSON("Life.json", function(life) {
      App.contracts.Life = TruffleContract(life);
      App.contracts.Life.setProvider(App.web3Provider);
      return App.render();
    });
  },

  listenForEvents1: function() {
    App.contracts.Life.deployed().then(function(instance) {
      instance.display({}, {
        fromblock: 'latest',
        toBlock: 'latest'
      }).watch(function(error, event) {
        console.log("event triggered", event.args.result)
        $('#result1').html("you have successfully registered. Your ID is" + event.args.result);
      });
    });
  },

  listenForEvents2: function() {
    App.contracts.Life.deployed().then(function(instance) {
      instance.display({}, {
        fromblock: 'latest',
        toBlock: 'latest'
      }).watch(function(error, event) {
        console.log("event triggered", event.args.result)
        $('#result2').html("you have successfully registered. Your ID is" + event.args.result);
      });
    });
  },

  render: function() {
    web3.eth.getCoinbase(function(err, account) {
      if (err === null) {
        App.account = account;
        console.log(App.account);
      }
    });
  },

  patientRegister: function() {
    var hospitalName = $('#HospitalName').val();
    var bloodGroup = $('#BloodGroup1').val().toUpperCase();
    App.contracts.Life.deployed().then(function(instance) {
      return instance.addRecipiant(bloodGroup, hospitalName, {from: App.account});
    }).then(function(result) {
      App.listenForEvents1();
      console.log(result);
    }).catch(function(err) {
      console.log(err);
    });
  },

  donorRegister: function() {
    var bloodGroup = $('#BloodGroup').val().toUpperCase();
    App.contracts.Life.deployed().then(function(instance) {
      return instance.addDonor(bloodGroup, { from: App.account});
    }).then(function(result) {
      App.listenForEvents2();
      console.log(result);
    }).catch(function(err) {
      console.error(err);
    });
  },

  patientStatus: function() {
    var id = Number($('#pid').val());
    App.contracts.Life.deployed().then(function(instance) {
      return instance.checkRank(id, { from: App.account});
    }).then(function(result) {
      console.log(result);
      $('#result3').html(result);
    }).catch(function(err) {
      console.error(err);
    });
  },

  donorStatus: function() {
    var id = Number($('#did').val());
    App.contracts.Life.deployed().then(function(instance) {
      return instance.getStatusDonor(id, { from: App.account});
    }).then(function(result) {
      console.log(result);
      $('#result4').html(result);
    }).catch(function(err) {
      console.error(err);
    });
  }
};

$(function() {
  $(window).on('load', function() {
    App.init();
  });
});
